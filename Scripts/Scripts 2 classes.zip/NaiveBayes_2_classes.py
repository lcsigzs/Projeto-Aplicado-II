
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 14:07:37 2025

@author: Oscar Augusto de Oliveira Luz

Disciplina: Projeto Aplicado II

Grupo 13
Thaís Cristine de Andrade Gomes - 10721642
Paulo Ricardo de Oliveira Ramos - 10721464
Lucas Iglezias dos Anjos - 10433522
Oscar Augusto de Oliveira Luz - 10435099
"""

import joblib
from sklearn.naive_bayes import MultinomialNB
import pandas as pd
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix


# Carregar os conjuntos de dados e o vetorizador (2 classes)
X_train = joblib.load("X_train_2_classes.pkl")
X_test = joblib.load("X_test_2_classes.pkl")
y_train = joblib.load("y_train_2_classes.pkl")
y_test = joblib.load("y_test_2_classes.pkl")

# Chamar e treinar o modelo Multinomial Naive Bayes
model = MultinomialNB()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Avaliar o modelo
acuracia = accuracy_score(y_test, y_pred)
relatorio = classification_report(y_test, y_pred)

# Salvar e apresentar os resultados
joblib.dump(model, "multinomial_nb_model_2_classes.pkl")

print("\n--- Resultados da Avaliação (2 Classes) ---")
print(f"Acurácia: {acuracia:.4f}")
print("\nRelatório de Classificação:\n", relatorio)

# MATRIZ DE CONFUSÃO
cm = confusion_matrix(y_test, y_pred, labels=model.classes_)

# Dataframe da matriz de conf. 
cm_df = pd.DataFrame(cm, index=model.classes_, columns=model.classes_)
print("\nMatriz de Confusão:")
print(cm_df)
