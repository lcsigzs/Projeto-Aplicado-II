
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 19:15:06 2025

@author: Oscar Augusto de Oliveira Luz

Disciplina: Projeto Aplicado II

Grupo 13
Thaís Cristine de Andrade Gomes - 10721642
Paulo Ricardo de Oliveira Ramos - 10721464
Lucas Iglezias dos Anjos - 10433522
Oscar Augusto de Oliveira Luz - 10435099
"""

import pandas as pd
import re
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# Carregar o dataset
df = pd.read_csv("tinder_google_play_reviews.csv")

# Remover linhas com valores nulos na coluna 'content' - excluindo as reviews vazias
df.dropna(subset=["content"], inplace=True)

# Lemmatizer e stopwords - trazendo mais significado para a análise de sentimento & excluindo palavras que pouco agregram a análise)
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words("english")) # Usamos stopwords em inglês, por ser a maioria neste dataset

# Limpeza dos textos
def clean_text(text):
    text = text.lower() 
    text = re.sub(r"[^a-z]", " ", text) # manter apenas letras do alfabeto inglês
    text = re.sub(r"\\s+", " ", text).strip() # Remover espaços extras
    tokens = word_tokenize(text, language="english") # Tokenizar em inglês
    # Remover stopwords e lematizar
    cleaned_tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
    return " ".join(cleaned_tokens)

df["cleaned_content"] = df["content"].apply(clean_text)

df[["content", "cleaned_content", "score"]].to_csv("tinder_google_play_limpo_2_classes.csv", index=False)

################# CATEGORIZACAO DOS SENTIMENTOS (2 CLASSES)

def categorizar_sentimento_2_classes(score):
    if score in [1, 2, 3]:
        return "Negativo"
    elif score in [4, 5]:
        return "Positivo"
    else:
        return "Desconhecido"

df["sentiment"] = df["score"].apply(categorizar_sentimento_2_classes)

df.to_csv("tinder_google_play_categorizado_2_classes.csv", index=False)

################################### Vetorização e Divisão de Treino/Teste

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import joblib

df = pd.read_csv("tinder_google_play_categorizado_2_classes.csv")

# Remover linhas com valores nulos na coluna 'cleaned_content' - para validar a limpeza feita anteriormente
df.dropna(subset=["cleaned_content"], inplace=True)

X = df["cleaned_content"]
y = df["sentiment"]

tfidf_vectorizer = TfidfVectorizer(max_features=2000) 

# Vetorizar os textos
X_vectorized = tfidf_vectorizer.fit_transform(X)

# Dividir os dados em conjuntos de treino e teste
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42, stratify=y)

joblib.dump(tfidf_vectorizer, "tfidf_vectorizer_2_classes.pkl")
joblib.dump(X_train, "X_train_2_classes.pkl")
joblib.dump(X_test, "X_test_2_classes.pkl")
joblib.dump(y_train, "y_train_2_classes.pkl")
joblib.dump(y_test, "y_test_2_classes.pkl")

print(f"Shape de X_train: {X_train.shape}")
print(f"Shape de X_test: {X_test.shape}")
print(f"Shape de y_train: {y_train.shape}")
print(f"Shape de y_test: {y_test.shape}")
